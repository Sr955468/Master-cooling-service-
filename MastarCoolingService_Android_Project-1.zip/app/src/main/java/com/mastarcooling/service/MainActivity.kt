package com.mastarcooling.service

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.Color
import android.net.Uri
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

data class Entry(
    val id: Long, var date: String, var name: String, var phone: String,
    var address: String, var work: String, var amount: String, var status: String
)

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("data", MODE_PRIVATE) }
    private val entries = mutableListOf<Entry>()
    private lateinit var list: LinearLayout
    private lateinit var search: EditText

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        load()
        home()
    }

    private fun tv(s:String, size:Float=16f): TextView = TextView(this).apply {
        text=s; textSize=size; setPadding(24,18,24,18)
    }
    private fun btn(s:String, click:()->Unit)=Button(this).apply { text=s; setOnClickListener{click()} }

    private fun home() {
        val scroll=ScrollView(this)
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(16,16,16,16) }
        box.addView(tv("❄️  MASTAR COOLING SERVICE",25f))
        box.addView(tv("AC • Refrigerator • Deep Freezer • Washing Machine",15f))
        box.addView(btn("➕  नई Service Entry"){form(null)})
        box.addView(btn("📅  Attendance / Service List"){showList()})
        box.addView(btn("📤  Export CSV (Excel में खोलें)"){exportCsv()})
        box.addView(btn("ℹ️  App Information"){
            AlertDialog.Builder(this).setTitle("Mastar Cooling Service")
                .setMessage("Service & Attendance Manager\\nVersion 1.0")
                .setPositiveButton("OK",null).show()
        })
        scroll.addView(box); setContentView(scroll)
    }

    private fun form(old: Entry?) {
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,10,18,10)}
        fun field(h:String,v:String=""):EditText=EditText(this).apply{hint=h;setText(v)}
        val date=field("Date (DD/MM/YYYY)", old?.date ?: SimpleDateFormat("dd/MM/yyyy",Locale.getDefault()).format(Date()))
        val name=field("Customer / Staff Name",old?.name?:"")
        val phone=field("Mobile Number",old?.phone?:"")
        val address=field("Address",old?.address?:"")
        val work=field("Work (AC/Fridge/etc.)",old?.work?:"")
        val amount=field("Amount ₹",old?.amount?:"")
        val status=field("Status (Pending/Done/Paid)",old?.status?:"Done")
        listOf(date,name,phone,address,work,amount,status).forEach{box.addView(it)}
        box.addView(btn(if(old==null)"SAVE ENTRY" else "UPDATE ENTRY"){
            if(name.text.toString().trim().isEmpty()){
                Toast.makeText(this,"Name डालें",Toast.LENGTH_SHORT).show(); return@btn
            }
            val e=Entry(old?.id ?: System.currentTimeMillis(),date.text.toString(),name.text.toString(),
                phone.text.toString(),address.text.toString(),work.text.toString(),amount.text.toString(),status.text.toString())
            if(old==null) entries.add(e) else { val i=entries.indexOfFirst{it.id==old.id}; if(i>=0) entries[i]=e }
            save(); Toast.makeText(this,"Entry save हो गई",Toast.LENGTH_SHORT).show(); showList()
        })
        box.addView(btn("CANCEL"){showList()})
        val s=ScrollView(this);s.addView(box);setContentView(s)
    }

    private fun showList() {
        val outer=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(12,12,12,12)}
        outer.addView(btn("← HOME"){home()})
        search=EditText(this).apply{hint="🔍 Search name / phone / work"}
        outer.addView(search)
        list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        outer.addView(list)
        setContentView(ScrollView(this).apply{addView(outer)})
        search.addTextChangedListener(object:android.text.TextWatcher{
            override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){}
            override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){render(s.toString())}
            override fun afterTextChanged(e:android.text.Editable?){}
        })
        render("")
    }

    private fun render(q:String) {
        list.removeAllViews()
        val filtered=entries.filter{("${it.name} ${it.phone} ${it.work} ${it.address}").contains(q,true)}
        if(filtered.isEmpty()){list.addView(tv("कोई entry नहीं मिली."));return}
        filtered.reversed().forEach { e ->
            val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(8,8,8,8)}
            card.setBackgroundColor(Color.rgb(238,245,252))
            card.addView(tv("📅 ${e.date}   👤 ${e.name}",18f))
            card.addView(tv("📞 ${e.phone}\n📍 ${e.address}\n🔧 ${e.work}\n💰 ₹${e.amount}   •   ${e.status}",15f))
            val row=LinearLayout(this)
            row.addView(btn("✏️ EDIT"){form(e)},LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f))
            row.addView(btn("🗑 DELETE"){
                AlertDialog.Builder(this).setTitle("Delete?")
                    .setMessage("यह entry हटानी है?")
                    .setNegativeButton("NO",null).setPositiveButton("YES"){_,_->entries.removeIf{it.id==e.id};save();render(search.text.toString())}.show()
            },LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1f))
            card.addView(row);list.addView(card)
        }
    }

    private fun save(){
        val arr=entries.joinToString("\n"){listOf(it.id,it.date,it.name,it.phone,it.address,it.work,it.amount,it.status)
            .joinToString("|")}
        prefs.edit().putString("entries",arr).apply()
    }
    private fun load(){
        prefs.getString("entries","")!!.lines().filter{it.isNotBlank()}.forEach{
            val p=it.split("|"); if(p.size>=8) entries.add(Entry(p[0].toLong(),p[1],p[2],p[3],p[4],p[5],p[6],p[7]))
        }
    }
    private fun exportCsv(){
        val csv=buildString{
            append("Date,Name,Phone,Address,Work,Amount,Status\n")
            entries.forEach{e->append(listOf(e.date,e.name,e.phone,e.address,e.work,e.amount,e.status)
                .joinToString(","){ "\""+it.replace("\"","\"\"")+"\"" }+"\n")}
        }
        val uri=contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI,
            android.content.ContentValues().apply{
                put(android.provider.MediaStore.Downloads.DISPLAY_NAME,"Mastar_Cooling_Service.csv")
                put(android.provider.MediaStore.Downloads.MIME_TYPE,"text/csv")
            })
        if(uri!=null){contentResolver.openOutputStream(uri)?.use{it.write(csv.toByteArray())}
            Toast.makeText(this,"CSV Downloads folder में save हो गई",Toast.LENGTH_LONG).show()
        } else Toast.makeText(this,"Export failed",Toast.LENGTH_SHORT).show()
    }
}
