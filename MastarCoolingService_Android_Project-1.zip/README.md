# Mastar Cooling Service — Android App

Features:
- Home screen
- New service/attendance entry
- Edit/Delete
- Search
- Local data saving
- CSV export (opens in Excel)
- Portrait mobile UI

## Build
Open this folder in Android Studio, allow Gradle sync, then:
Build > Build App Bundle(s) / APK(s) > Build APK(s)

The generated APK can be installed on an Android phone.
